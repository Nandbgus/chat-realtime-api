// controllers/message.controller.js
import Message from '../models/message.model.js';
import Chat from '../models/chat.model.js';

import { getSocketIO } from '../sockets/socket.instance.js'; // buat instance getter
// controllers/message.controller.js
import User from '../models/user.model.js';

export const createMessage = async (req, res) => {
  try {
    const { content } = req.body;
    const { chatId } = req.params;
    const senderId = req.user._id;

    if (!content || !chatId) {
      return res.status(400).json({ message: 'Invalid data' });
    }

    const chat = await Chat.findById(chatId);
    if (!chat || !chat.members.includes(senderId)) {
      return res.status(403).json({ message: 'Unauthorized' });
    }

    const newMessage = new Message({
      chat: chatId,
      sender: senderId,
      content,
    });

    const savedMessage = await newMessage.save();

    const populatedMessage = await savedMessage
      .populate('sender', 'username email')
      .populate('chat')
      .execPopulate();

    const io = getSocketIO();
    io.to(chatId).emit('newMessage', populatedMessage);

    res.status(201).json(populatedMessage);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};


export const sendMessage = async (req, res, next) => {
  try {
    const { content } = req.body;
    const { chatId } = req.params;

    const newMessage = await Message.create({
      sender: req.user.id,
      content,
      chat: chatId,
    });

    const populatedMessage = await newMessage.populate('sender', 'username _id');

    // Emit ke room chatId
    const io = getSocketIO(); // instance io yang disimpan saat `initSocket` dipanggil
    io.to(chatId).emit('newMessage', populatedMessage);

    res.status(201).json(populatedMessage);
  } catch (err) {
    next(err);
  }
};


export const getMessagesByChatId = async (req, res) => {
  try {
    const { chatId } = req.params;

    const messages = await Message.find({ chat: chatId })
  .populate({
    path: 'sender',
    select: 'username _id', // hanya kirim username dan _id
  })
  .sort({ createdAt: 1 });


    res.status(200).json({ success: true, data: messages });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
