// routes/message.routes.js
import express from 'express';
import { authenticate } from '../middlewares/auth.middleware.js';
import { sendMessage, getMessagesByChatId } from '../controllers/message.controller.js';

const router = express.Router();

// ✅ Route untuk mengirim pesan (POST /api/messages/:chatId)
router.post('/:chatId', authenticate, sendMessage);

// ✅ Route untuk mengambil semua pesan dalam chat tertentu
router.get('/:chatId', authenticate, getMessagesByChatId);

export default router;
