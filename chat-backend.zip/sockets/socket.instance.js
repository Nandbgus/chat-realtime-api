let io = null;

export const setSocketIO = (ioInstance) => {
  io = ioInstance;
};

export const getSocketIO = () => {
  return io;
};
